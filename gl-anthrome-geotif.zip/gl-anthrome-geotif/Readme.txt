Anthropogenic Biomes Dataset

DESCRIPTION
This archive contains the Anthropogenic Biomes dataset, created by Ellis and Ramankutty. Documentation for data is available at these web sites:

http://sedac.ciesin.columbia.edu/es/anthropogenicbiomes.html

Updates and corrections may still be made. If you should discover any problems or errors, please inform us by sending an email describing the issue to: ciesin.info@ciesin.columbia.edu

The archive contains either the global or continental Anthropogenic Biome grids. The grids are available as compressed zipfiles of ESRI GRIDS or GeoTIFFs. To access the grids the contents of the zipfiles must be extracted into a single folder. 

DOWNLOADING DATA
The data can be downloaded via the World Wide Web at http://sedac.ciesin.columbia.edu/es/anthropogenicbiomes.html. 

Downloaded files need to be uncompressed using either WinZip (Windows file compression utility) or similar applications before they could be accessed by your GIS software package. Users should expect some increase in the size of downloaded data after decompression. 

The codes for the different layers in the data files represent the following anthropogenic biome type:

 
Grid Value	LABEL,	GROUP	   
11	11: Urban,	Dense settlements	   
12	12: Dense settlements,	Dense settlements	   
22	22: Irrigated villages,	Villages	   
23	23: Cropped & pastoral villages,	Villages	   
24	24: Pastoral villages,	Villages	   
25	25: Rainfed villages,	Villages	   
26	26: Rainfed mosaic villages,	Villages	   
31	31: Residential irrigated cropland,	Croplands	   
32	32: Residential rainfed mosaic,	Croplands	   
33	33: Populated irrigated cropland,	Croplands	   
34	34: Populated rainfed cropland,	Croplands	   
35	35: Remote croplands,	Croplands	   
41	41: Residential rangelands,	Rangelands	   
42	42: Populated rangelands,	Rangelands	   
43	43: Remote rangelands,	Rangelands	   
51	51: Populated forests,	Forested	   
52	52: Remote forests,	Forested	   
61	61: Wild forests,	Wildlands	   
62	62: Sparse trees,	Wildlands	   
63	63: Barren,	Wildlands	 

WORKING WITH GeoTIFF ZIPFILES
GeoTIFF defines a set of publicly available TIFF tags that describe cartographic and geodetic information associated with TIFF images. GeoTIFF is a format that enables referencing a raster image to a known geodetic model or map projection. The initial tags are followed by image data that, in turn, may be interrupted by more descriptive tags.  By using the GeoTIFF format, both metadata and image data are encoded into the same file. Users may be may require conversion tools to convert to their desired GIS or Remote Sensing image formats.

To access the files content of the zip file must be uncompressed in a single folder. Users may require conversion tools to convert the TIF files to their desired GIS formats. The data are stored in geographic coordinates of decimal degrees based on the World Geodetic System spheroid of 1984 (WGS84).

To view these data in ArcMap, simply unzip to an accessible directory and open the layer file.

USE CONSTRAINTS
The Trustees of Columbia University and the originators hold the copyright of this dataset. Users are prohibited from any commercial sale or free redistribution without explicit written permission from CIESIN. Users should acknowledge CIESIN and the originators, as the source used in the creation of any reports, publications, new datasets, derived products, or services resulting from the use of this dataset. CIESIN also requests reprints of any publications and notification of any redistributing efforts.

DATA ERRORS, CORRECTIONS AND QUALITY ASSESSMENT
CIESIN follows procedures designed to ensure that data disseminated by CIESIN are of reasonable quality. If, despite these procedures, users encounter apparent errors or misstatements in the data, they should contact us at http://www.ciesin.columbia.edu. 

NO WARRANTY OR LIABILITY
CIESIN and the creators provide these data without any warranty of any kind whatsoever either express or implied. Neither CIESIN nor the creators shall be liable for incidental, consequential, or special damages arising out of the use of any data downloaded.

ACKNOWLEDGMENT AND CITATION
The recommended citation for this data is:
Ellis, E. C. and N. Ramankutty. 2008. Putting people in the map: anthropogenic biomes of the world. Data distributed by the Socioeconomic Data and Applications Center (SEDAC): http://sedac.ciesin.columbia.edu/es/anthropogenicbiomes.html. [Date downloaded]


August 20, 2009